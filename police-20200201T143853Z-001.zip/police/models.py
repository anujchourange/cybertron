import re
from django.db import models
from django.core.validators import RegexValidator

# Create your models here.
from django.db import models
from django import forms

class police(models.Model):
    fname_regex = RegexValidator(regex=r'^[a-zA-Z\s]+$', message="Valid name should be entered")
    fname = models.CharField(validators=[fname_regex], max_length=20, blank=False)
    lname_regex = RegexValidator(regex=r'^[a-zA-Z\s]+$', message="Valid name should be entered")
    lname = models.CharField(validators=[lname_regex], max_length=20, blank=False)
    email = models.EmailField(max_length=254, blank=False,help_text='Required. Inform a valid email address')
    phone_regex = RegexValidator(regex=r'^(0/91)?[7-9][0-9]{9}', message="Valid phone number should be entered")
    phone_number = models.CharField(validators=[phone_regex], max_length=20, blank=False) # validators should be a list
    password = models.CharField(max_length=20, blank=False)
    branch = models.CharField(max_length=20, blank=False)
    post = models.CharField(max_length=20, blank=False)
    
    def __str__(self):
        return self.email
   


    
    

