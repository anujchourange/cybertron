from django import forms
from User.models import *
from apps.models import police

class PoliceForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    #confirm_password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = Police
        fields = ('fname','lname','email','phone_number','password','branch','post')