from django.apps import AppConfig


class PoliceConfig(AppConfig):
    name = 'police'
