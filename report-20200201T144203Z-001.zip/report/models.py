import re
from django.db import models
from django.core.validators import RegexValidator
from django.utils import timezone
import datetime
from django import forms


class report(models.Model):
    event_time = models.DateTimeField(editable=False,auto_now_add=True)
    event_report = models.DateTimeField(editable=False,auto_now=True)
    image= models.ImageField(upload_to=None, height_field=None, width_field=None, max_length=100)
    location = models.models.DecimalField(max_digits=22, decimal_places=16)
    status=models.IntegerRangeField(min_value=0, max_value=1)
    title= models.CharField(max_length=50)
    description=forms.CharField(max_length=100)
    
    def __str__(self):
        return f"Report " + self.id
   


    
    
